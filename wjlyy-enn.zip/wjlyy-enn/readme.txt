Requirements
Python 3
TensorFlow 2 above
numpy
scikit-learn
scipy
keras
pandas

Models
Run bgru.py to train the model.
Run enn.py to train the model.

Process
First, we should configure the runtime environment, then run bgru.py, enn.py. The parameters of learn rate, batch_size, epoch, dropout, optimizer, loss function are set to the appropriate values, and finally the training model can be started.
